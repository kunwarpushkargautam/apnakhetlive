exports.ProductList = [
    {
        productid: "m1",
        name: "Bambai Mango",
        price: 800,
        image:"/images/img3.jpg",
        incart: 0

    },
    {
        productid: "m3",
        name: "Langda Mango",
        price: 1000,
        image:"/images/img3.jpg",
        incart: 0

    },
    {
        productid: "m4",
        name: "seasonal Mango",
        price: 1300,
        image:"/images/img3.jpg",
        incart: 0
    },
    {
        productid: "m5",
        name: "Achhar Mango",
        price: 1200,
        image:"/images/img3.jpg",
        incart: 0
    }
];